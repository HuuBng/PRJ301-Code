package pe.employee;

public class EmployeeDTO {
    //your code here
    
}
